const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth");
const {enable2FA, verify2FA, disable2FA} = require("./../controllers/Auth2FAController");


router.post('/2fa/enable', auth, enable2FA);
router.post('/2fa/verify', auth, verify2FA);
router.post('/2fa/disable', auth, disable2FA);

module.exports = router;